# Morocco Retail Intelligence

A portfolio project that turns raw e-commerce data into actionable business insights through Python analytics, visualizations and a REST API.

## Planned stack
Python, Pandas, Matplotlib, Seaborn, FastAPI, Pydantic, PostgreSQL, pytest.

## Roadmap
1. Data understanding and quality audit
2. Data cleaning and preparation
3. Exploratory data analysis (EDA)
4. Business KPI analysis
5. Data visualization and insight reporting
6. Analytics API with FastAPI
7. Tests, documentation and deployment

## Dataset
See `data/raw/` and `README_DATA.md`. The data is synthetic and intended for educational use.
