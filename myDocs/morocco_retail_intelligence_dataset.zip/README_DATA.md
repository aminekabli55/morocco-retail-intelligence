# Morocco Retail Intelligence — Dataset

## Dataset overview
Synthetic e-commerce dataset for a fictional Moroccan retailer. All records are generated for learning and portfolio practice; they do not describe real customers or transactions.

## Files
- customers.csv: customer profile, city, segment and signup date
- products.csv: product catalog, category, prices and stock status
- orders.csv: order dates, statuses, delivery dates, city and shipping fee
- order_items.csv: products and quantities purchased in each order
- payments.csv: payment method, status and amount
- reviews.csv: customer ratings and review comments

## Relationships
- customers.customer_id -> orders.customer_id
- orders.order_id -> order_items.order_id
- products.product_id -> order_items.product_id
- orders.order_id -> payments.order_id
- orders.order_id -> reviews.order_id

## Notes
- Currency: Moroccan dirham (MAD)
- Date range: 2024–2025
- Deliberate data-quality issues are included: missing values and duplicate order rows.
- `line_total_mad` is the item line total after discount, excluding shipping.
- Revenue analysis should explicitly decide how to treat cancelled and returned orders.

## Suggested first checks
1. Read each CSV with pandas.
2. Inspect shape, columns, dtypes and missing values.
3. Check duplicate IDs and relationship integrity.
4. Parse date columns.
5. Document cleaning decisions before modifying data.
